




from kivy.core.window import Window
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivymd.app import MDApp
from kivymd.uix.list import OneLineAvatarIconListItem
from kivymd.icon_definitions import md_icons

from kivy.uix.floatlayout import FloatLayout
from kivymd.uix.list import IconLeftWidget, IconRightWidget

from kivymd.uix.button import MDFloatingActionButton




Builder.load_string("""

<First_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1
            FloatLayout:
                size: 50, 100





            FloatLayout:
                Image:
                    source: 'puimuri_teksti_kuva.png'
                    size: 200, 100
                    size_hint: None, None
                    pos_hint: {'x': 0, 'y': -2.3} 

        
            FloatLayout:
                Image:
                    source: 'puimuri_transparent.png'
                    size: 80, 100
                    size_hint: None, None
                    pos_hint: {'x': 0.75, 'y': -0.9}  
                            
        MDLabel:


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9

                
    MDBoxLayout:
        
        pos_hint: {'x': 0, 'y': 0.4}
        MDList:

            OneLineAvatarIconListItem:
                text: 'POWER (P)'
                on_release: root.manager.current = 'P'
                IconLeftWidget: 
                    icon: 'power-plug'

            OneLineAvatarIconListItem:
                text: 'VOLTAGE (U)'
                on_release: root.manager.current = 'U'
                IconLeftWidget: 
                    icon: 'lightning-bolt'
            OneLineAvatarIconListItem:
                text: 'CURRENT (I)'
                on_release: root.manager.current = 'I'
                IconLeftWidget: 
                    icon: 'current-ac'
            OneLineAvatarIconListItem:
                text: 'RESISTANCE (R)'
                on_release: root.manager.current = 'R'
                IconLeftWidget: 
                    icon: 'omega'
                    
<P_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1
        
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'POWER (P)'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'power-plug'
                    opposite_colors: True
                            
        MDLabel:


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9
    
    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'first'
        

            
# kaava kuvat
    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'P1m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': 0}


    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'P2m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.2}

    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'P3m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.4}      

    MDFloatingActionButton:
        pos_hint: {'center_x': .7, 'center_y': .18}
        elevation: 2.5
        icon: 'information-variant'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'P_info'  
                    
        
                    
<U_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1
        
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'VOLTAGE (U)'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'lightning-bolt'
                    opposite_colors: True
        MDLabel:


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9
    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'first'

            
# kaava kuvat
    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'U1m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': 0}


    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'U2m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.2}

    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'U3m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.4}   

    MDFloatingActionButton:
        pos_hint: {'center_x': .7, 'center_y': .18}
        elevation: 2.5
        icon: 'information-variant'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'U_info'         
<I_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1
        
            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'CURRENT (I)'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'current-ac'
                    opposite_colors: True
                            
        MDLabel:


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9
    
    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9
    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'first'

    MDFloatingActionButton:
        pos_hint: {'center_x': .7, 'center_y': .18}
        elevation: 2.5
        icon: 'information-variant'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'I_info'
                                      
# kaava kuvat
    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'I1m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': 0}


    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'I2m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.2}

    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'I3m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.4}
                    
    MDFloatingActionButton:
        pos_hint: {'center_x': .7, 'center_y': .18}
        elevation: 2.5
        icon: 'information-variant'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'I_info'
<R_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1

            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'RESISTANCE (R)'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'omega'
                    opposite_colors: True
                    
                            
        MDLabel:


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9


    FloatLayout:
        size: 100, 100
        size_hint: None, None
        canvas:
            Color:
                rgba: 0.6, 0, 1, 1
            Rectangle:
                pos: 0,0
                size: 2000, root.height / 9
    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'first'
# kaava kuvat
    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'R1m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': 0}


    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'R2m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.2}

    FloatLayout:
        pos_hint: {'x': 0.5, 'y': 0.6}

        Image:
            source: 'R3m.png'
            size: 200, 200
            size_hint: None, None
            pos_hint: {'x': -0.5, 'y': -0.4}      

            
    MDFloatingActionButton:
        pos_hint: {'center_x': .7, 'center_y': .18}
        elevation: 2.5
        icon: 'information-variant'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'R_info'


<P_Info_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1

            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'INFO'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'omega'
                    opposite_colors: True
                    
                            
        MDLabel:

    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'P'
<U_Info_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1

            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'INFO'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'omega'
                    opposite_colors: True
                    
                            
        MDLabel:

        
    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'U'
<I_Info_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1

            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'INFO'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'omega'
                    opposite_colors: True
                    
                            
        MDLabel:

    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'I'
<R_Info_Screen>
    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            elevation: 2
            md_bg_color: 0.6, 0, 1, 1

            
            FloatLayout:
                size: 50, 100

                Label:

                    text: 'INFO'
                    pos_hint: {'x': 0.05, 'y': -.05}
                    font_size: 20  # set the font size to 20
                    bold: True  # make the text bold
                    size_hint: None, None
                    size: self.texture_size  # Set the size of the label to fit its text
                    
            FloatLayout:
                size: 100, 100

                IconRightWidget:                    

                    pos_hint: {'x': 0.8, 'y': 0.3}
                    icon: 'omega'
                    opposite_colors: True
                    
                            
        MDLabel:

    MDFloatingActionButton:
        pos_hint: {'center_x': .5, 'center_y': .18}
        elevation: 2.5
        icon: 'arrow-left-bold'
        md_bg_color: 0.6, 0, 1, 1


        on_release:
            root.manager.current = 'R'
        
""")








# first
class First_Screen(Screen):
    pass
# Power screens
class P_Screen(Screen):
    pass
class P_Info_Screen(Screen):
    pass
# Voltage Screen
class U_Screen(Screen):
    pass
class U_Info_Screen(Screen):
    pass
# Current Screens
class I_Screen(Screen):
    pass
class I_Info_Screen(Screen):
    pass

# Resistance screens
class R_Screen(Screen):
    pass

class R_Info_Screen(Screen):
    pass



class TestApp(MDApp):

    def build(self):

         # Set the window size and aspect ratio to match a phone screen
        Window.size = (350,600)
        Window.size_hint = (None, None)
        Window.aspect_ratio = 9/16
        
        # Create the screen manager

        sm = ScreenManager()
        sm.add_widget(First_Screen(name='first'))
        sm.add_widget(P_Screen(name='P'))
        sm.add_widget(U_Screen(name='U'))
        sm.add_widget(I_Screen(name='I'))
        # P screen screenmanager
        sm.add_widget(P_Screen(name='P'))
        sm.add_widget(P_Info_Screen(name='P_info'))
        # U screen screenmanager
        sm.add_widget(U_Screen(name='U'))
        sm.add_widget(U_Info_Screen(name='U_info'))
        # I screen screenmanager
        sm.add_widget(I_Screen(name='I'))
        sm.add_widget(I_Info_Screen(name='I_info'))
        # R screen screenmanager
        sm.add_widget(R_Screen(name='R'))
        sm.add_widget(R_Info_Screen(name='R_info'))


        return sm

if __name__ == '__main__':
    TestApp().run()















